from colorama import *
from datetime import datetime
def info(color_status=True,msg=""):
    if color_status == True:
        current_time = datetime.now().strftime("%H:%M:%S")
        print(f" {current_time}{Fore.GREEN} INFO: {Fore.RESET}{msg}")
    elif color_status == False:
        current_time = datetime.now().strftime("%H:%M:%S")
        print(f" {current_time} INFO: {msg}")

def error(color_status=True,msg=""):
    if color_status == True:
        current_time = datetime.now().strftime("%H:%M:%S")
        print(f" {current_time}{Fore.RED} ERROR: {Fore.RESET}{msg}")
    elif color_status == False:
        current_time = datetime.now().strftime("%H:%M:%S")
        print(f" {current_time} ERROR: {msg}")
