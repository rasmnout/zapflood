import rsmntmessage as RasmnoutMessage
import Zapprint as ZapFloodPrint
import argparse
import sys
import zapfloodSessionStillLive1 as LiveStill
import zapfloodSessionStill as Still
import zapfloodSessionStillChannel as ChannelStill
import zapfloodSessionChannel as Channel
import zapfloodSessionLive as Live
import zapfloodSessionLiveChannel as LiveChannel
def main():
    colors = True
    parser = argparse.ArgumentParser(description="zapflood: Program for deauth flood")
    parser.add_argument('-i', '--interface', type=str, help="Select interface for deauth flood")
    parser.add_argument('-s', '--still', action='store_true', help="Run deauth flood continuously")
    parser.add_argument('-c', '--channel', type=int, help="Set the channel for deauth flood, it will deauth all networks on the selected channel")
    parser.add_argument('--live', action='store_true', help="Console with overview information")
    parser.add_argument('--no-color', action='store_true', help="No Colors")
    parser.add_argument('--version', action='store_true', help="Version ZapFlood Console")
    args = parser.parse_args()

    if args.no_color:
        colors = False

    if colors:
        print(ZapFloodPrint.logo_with_colors)
    else:
        print(ZapFloodPrint.logo_without_colors)

    if not args.interface and not args.version:
        RasmnoutMessage.error(color_status=True, msg="No Interface Selected")
        sys.exit(1)

    interface = args.interface

    if args.version:
        print("Rasmnout ZapFlood Console v0.1.1Q")
        
    elif args.still:
        if args.live:
            if colors:
                LiveStill.session_with(interface=interface)
            else:
                LiveStill.session_without(interface=interface)
        if args.channel:
            channel = args.channel
            if colors:
                results = ChannelStill.session_with(channel, interface=interface)
                if results == "No Interface":
                    RasmnoutMessage.error(color_status=True, msg="Not Selected Interface")
            else:
                results = ChannelStill.session_without(channel, interface=interface)
                if results == "No Interface":
                    RasmnoutMessage.error(color_status=True, msg="Not Selected Interface")

        if colors:
            results = Still.session_with(interface=interface)
            if results == "No Interface":
                RasmnoutMessage.error(color_status=True, msg="Not Selected Interface")
        else:
            results = Still.session_without(interface=interface)
            if results == "No Interface":
                RasmnoutMessage.error(color_status=True, msg="Not Selected Interface")

    if args.channel:
        channel = args.channel
        if colors:
            results = Channel.session_with(channel, interface=interface)
            if results == "No Interface":
                RasmnoutMessage.error(color_status=True, msg="Not Selected Interface")
        else:
            results = Channel.session_without(channel, interface=interface)
            if results == "No Interface":
                RasmnoutMessage.error(color_status=True, msg="Not Selected Interface")

    if args.live:
        if args.channel:
            if colors:
                LiveChannel.session_with(interface=interface)
            else:
                LiveChannel.session_without(interface=interface)
        else:
            if colors:
                Live.session_with(interface=interface)
            else:
                Live.session_without(interface=interface)

if __name__ == '__main__':
    main()
